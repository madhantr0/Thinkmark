# ThinkMark — Gamma AI Content
## Team Firefox | Ideathon 2026 | Erode Sengunthar Engineering College
### Copy each slide content below into Gamma AI

---

## SLIDE 1 — Title (Topic of Presentation)

**ThinkMark**
AI-Powered IoT Exam Answer Sheet Evaluator

*"Let AI Think. Let Teachers Teach."*

Team Firefox | Erode Sengunthar Engineering College | Ideathon 2026

---

## SLIDE 2 — Team Members

**Team Firefox 🦊**

**T. Madhan** — Project Lead & Full Stack Developer
**M. Kalishwar** — Hardware Assistant
**L. Ramraj** — Research & Documentation
**SK. Divyanand** — Presentation & Design

Guide: [Faculty Name] — Department of [Your Dept]

---

## SLIDE 3 — Problem Statement

**The Problem with Exam Correction Today**

- Teachers manually correct 500–1000 answer sheets every exam season
- Results take 3 to 7 days — students wait anxiously
- Human fatigue leads to inconsistent and unfair marking
- Spelling mistakes unfairly punish students who know the concept
- No existing tool supports Tamil language handwritten answer evaluation
- All current AI solutions are software only — no affordable hardware for rural schools

**The Reality:**
Over 1.2 crore students write Tamil Nadu board exams every year.
Every paper is manually corrected by an exhausted teacher.
ThinkMark is here to change that.

---

## SLIDE 4 — Proposed Solution - Idea

**What is ThinkMark?**

A T-shaped handheld IoT scanner device that reads handwritten exam answer sheets and evaluates them instantly using online AI — supporting all subjects and Tamil/English languages.

**How It Works:**
1. Staff uploads question paper and answer key via Web UI before exam
2. Teacher swipes answer sheet through ThinkMark T-scanner
3. Arduino + ESP8266 WiFi module captures image and sends to online AI
4. AI evaluates theory answers, math equations, graphs, Tamil and English writing
5. Marks, grade and analysis appear instantly on any phone or laptop browser
6. Green LED = Pass | Red LED = Fail | Buzzer confirms each scan

**Workflow:**
Answer Sheet → T-Shape Scanner → Arduino + ESP8266 → WiFi → Online AI → Marks on Browser

**Supports:**
Theory (16 marks) | Math Equations | Graphs | Chemical Equations | Tamil | English | All Subjects

---

## SLIDE 5 — Proposed Solution (continued — use 1 of 5 allowed)

**ThinkMark Web Dashboard**

What the teacher sees after every scan:

Student Name: Arun Kumar
Roll No: 2024CS042
Subject: Mathematics

Q1 (16 marks) — 13 out of 16
Q2 (16 marks) — 14 out of 16
Q3 (8 marks) — 7 out of 8
Graph Question — 8 out of 10

Total: 42 out of 50
Result: PASS
Class Rank: 3 out of 60

Works on any Android phone, iPhone, laptop or tablet — No app installation needed!
Just connect to ThinkMark WiFi and open browser.

---

## SLIDE 6 — Expected Challenges During Implementation

**Technical Challenges & Our Solutions**

Challenge 1: Reading different handwriting styles
Solution: Train AI on Tamil Nadu school student handwriting samples

Challenge 2: Tamil OCR accuracy for cursive handwriting
Solution: Use Sarvam AI — India's best Tamil language AI model

Challenge 3: Graph shape recognition accuracy
Solution: Use Vision AI with shape detection algorithms

Challenge 4: Internet dependency for AI processing
Solution: Fast cloud API with local caching for speed

**Hardware Challenges & Solutions**

Challenge: Fitting Arduino + ESP8266 + Camera in compact T-shape body
Solution: Custom 3D printed modular casing with ventilation

Challenge: Battery life during long correction sessions
Solution: Efficient power management code + 18650 Li-ion battery

---

## SLIDE 7 — Social and Environmental Impact

**Social Impact**
- Saves 3 to 7 days of teacher correction time per exam season
- Fair and unbiased marking — no fatigue-based errors
- First tool to support Tamil language handwritten exam grading
- Affordable for government schools — under Rs. 4000
- Students get results faster — less stress and anxiety
- 1.2 crore Tamil Nadu students benefit directly

**Environmental Impact**
- Reduces paper used for mark sheets — fully digital reports
- Low power device — battery operated and energy efficient
- 3D printed body using recyclable materials
- Saves printing costs for schools

**Numbers That Matter:**
40 hours saved per teacher per exam season
10x cheaper than existing enterprise solutions
37,000+ Tamil Nadu government schools can use this

---

## SLIDE 8 — Market & Opportunity

**Target Market**
- Tamil Nadu Government Schools: 37,000+
- Engineering Colleges in Tamil Nadu: 500+
- Coaching Centres across Tamil Nadu: 10,000+
- CBSE and ICSE Private Schools

**Market Size**
- EdTech India Market 2026: $10.4 Billion
- Tamil Nadu Education Budget 2025: Rs. 38,000 Crore
- Our Addressable Market: Rs. 500 Crore

**Revenue Breakdown**
Device Sale: Rs. 3,999 per unit — Target: Schools
SaaS Subscription: Rs. 499 per month — Software access
Per Paper Pricing: Rs. 2 per paper — Exam boards
Enterprise License: Rs. 50,000 per year — Universities

Device Sales: 40%
SaaS Subscription: 35%
Per Paper Pricing: 15%
Enterprise License: 10%

---

## SLIDE 9 — Key Challenges (Competitive)

**How ThinkMark Beats Existing Solutions**

GradeLab — Web upload only, No hardware, No Tamil support
DASES — Cloud AI, Expensive, No offline, No Tamil
ExamAI — QR code based, No Tamil, No hardware device
Eklavvya — Enterprise software, Rs. 4.5 lakh per year, Too costly for schools

**ThinkMark Advantage**
- Only physical IoT hardware device in this space
- Only solution with Tamil language handwriting support
- Works with any phone browser — zero setup for teachers
- Under Rs. 4000 — 100x cheaper than competitors
- Online AI gives highest accuracy for all answer types
- Pre-upload question paper and answer key for smart evaluation

---

## SLIDE 10 — Prototype or any Experimental Analysis

**ThinkMark v0.1 — Current Prototype Status**

[INSERT YOUR PROTOTYPE IMAGE HERE — Left side of slide]

**Components Ready:**
- Arduino Uno board
- ESP8266 WiFi module
- Camera module for image capture
- Barcode scanner module
- Green and Red LED indicators
- Buzzer for audio feedback
- 18650 Battery with TP4056 charging

**What is Working Now:**
- WiFi web server running on Arduino + ESP8266
- Web dashboard accessible via browser at 192.168.4.1
- Barcode scan result showing on Web UI
- Works on Android and iPhone browser — no app needed

**Next Steps:**
- Integrate online AI evaluation engine
- Add Tamil OCR using Sarvam AI
- 3D print T-shape casing
- Field test in school environment

---

## SLIDE 11 — Business Model

**How ThinkMark Makes Money**

**Phase 1 — Year 1 — Prototype and Pilot**
Free pilot to 5 schools in Erode district
Collect real feedback and improve AI accuracy
Revenue: Investment phase

**Phase 2 — Year 2 — Launch**
Sell devices to schools at Rs. 3,999
Monthly SaaS for AI cloud features at Rs. 499 per month
Target: 100 schools — Rs. 40 lakh device revenue

**Phase 3 — Year 3 — Scale**
Partner with Tamil Nadu government school digitization program
Target: 1000 schools across Tamil Nadu
Revenue projection: Rs. 5 Crore per year

**Our Vision:**
Every teacher in Tamil Nadu should grade 60 answer sheets in 10 minutes — not 3 days.

---

## SLIDE 12 — Thank You

**ThinkMark**
*"Let AI Think. Let Teachers Teach."*

Team Firefox — Erode Sengunthar Engineering College — Ideathon 2026

T. Madhan | M. Kalishwar | L. Ramraj | SK. Divyanand

---
*How to use: Go to gamma.app → New → Paste in text → Select each slide content → Choose dark tech theme → Generate!*
